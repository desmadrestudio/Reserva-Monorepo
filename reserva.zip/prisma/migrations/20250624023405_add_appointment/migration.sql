-- AlterTable
ALTER TABLE "Appointment" ADD COLUMN "notes" TEXT;
