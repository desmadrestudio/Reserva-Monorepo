-- AlterTable
ALTER TABLE "Service" ADD COLUMN "variantId" TEXT;
