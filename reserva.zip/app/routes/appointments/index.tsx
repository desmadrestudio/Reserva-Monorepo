import { Page, Card } from "@shopify/polaris";

export default function AppointmentsIndex() {
  return (
    <Page title="Appointments">
      <Card sectioned>
        <p>This is the Appointments landing page. Use the sidebar to navigate further.</p>
      </Card>
    </Page>
  );
}