import { authenticate } from "~/shopify.server";
import { prisma as db } from "~/lib/prisma.server";

export const action = async ({ request }) => {
  const { shop, session } = await authenticate.webhook(request);


  // Webhook requests can trigger multiple times and after an app has already been uninstalled.
  // If this webhook already ran, the session may have been deleted previously.
  if (session) {
    await db.session.deleteMany({ where: { shop } });
  }

  return new Response();
};
