export default function PosAction() {
  return null;
}
