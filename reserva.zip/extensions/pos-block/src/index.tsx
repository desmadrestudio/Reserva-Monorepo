export default function PosBlock() {
  return null;
}
